rm(list=ls(all=TRUE))

#DIY Set directory and read the data 
setwd("")
data<-read.csv("CustomerData.csv",header=T)

#DIY Data Exploration - Check Data Structure, and Summary


#DIY remove CustomerID Column


#DIY convert City attribute as factor


#DIY split the data into train and test data sets (70/30 Split)
#DIY save train data to a dataframe named "train" and test data to a dataframe named "test"


# BUILD LINEAR REGRESSION MODEL 

# Build model with all attributes into model. 
# "TotalRevenueGenerated" is the target variable 
LinReg1<- lm( ??? ~ ., data=???)
summary(LinReg1)

#Review the residual plots
par(mfrow=c(2,2))
plot(LinReg1)
plot(LinReg1,which=4)
par(mfrow=c(1,1)) #reset default
# look at the residual and comment on them
# Do they  follow normal distribution? 
# Look at the other residual plots and check 
# whether the linear regression assumptions are 
# satisfied or not ? 
hist(LinReg1$residuals)
#predict(LinReg1)
#resid(LinReg1) #OBS-PRED 

# Error metrics evaluation on train data and test data
library(DMwR)
#Error verification on train data
regr.eval(train$TotalRevenueGenerated, LinReg1$fitted.values) 
#Error verification on test data
Pred<- 
  regr.eval(test$TotalRevenueGenerated, Pred)


#DIY Build model (LinReg2) with significant attributes and 
# check the model summaries




#DIY Error metrics evaluation on train data and test data 
# for LinReg2 Model





####################################################

####################################################
#Scaling the data
library(vegan)
str(data)
data_cat <- data[,c(1,11,12)]
data_num <- data[,-c(1,11,12)]
# Apply standardization. Ensure , you exclude the target variable 
#during standardization
data_num_std <- 

#Combine standardized attributes back with the 
# categorical attributes
data_std_final <- 

#Split the data into train(70%) and test data sets
rows= 
set.seed(123)
trainRows= 
train_std = data_std_final[trainRows,] 
test_std = data_std_final[-trainRows,]

# Build linear regression with all attributes
LinReg_std1 <- lm(TotalRevenueGenerated~., data=train_std)
summary(LinReg_std1)

#Error verification on train data


#Error verification on test data

# Check for multicollinearity 

# 1. VIF: (check attributes with high VIF value)
library(car)
vif(LinReg_std1)
str(train_std)
# remove the highly correlated attributes and 
# build the model 

LinReg_std2<- 
summary(LinReg_std2)
vif(LinReg_std2)
#Error verification on test data

# 2. Stepwise Regression
library(MASS)
Step1 <- stepAIC(LinReg_std1, direction="backward")
#Step2 <- stepAIC(LinReg1, direction="forward")
Step3 <- stepAIC(LinReg_std1, direction="both")
summary(Step3)
# select the final list of variables
# and build the model
Mass_LinReg1 <- 
summary(Mass_LinReg1)
par(mfrow=c(2,2))
plot(Mass_LinReg1)
plot(Mass_LinReg1,which=4)
par(mfrow=c(1,1))
head(train)
# Identify the outliers using the cook's distance
# remove them
# build model without the influencial points (record #2729) 
which(rownames(train_std)%in%c(???))
LinReg_No_infl<- 
summary(LinReg_No_infl)

#Error verification on train data
regr.eval(train_std$TotalRevenueGenerated, Mass_LinReg1$fitted.values) 
#Error verification on test data
MASS_Pred1<-predict(Mass_LinReg1,test_std)
regr.eval(test$TotalRevenueGenerated, MASS_Pred1)

Error_calc = data.frame(train_std$TotalRevenueGenerated,Mass_LinReg1$fitted.values)
write.csv(x = Error_calc,file = "Error_calc.csv")



##########Other Experiments
# Instead of removing the outliers, replace them with median
# If MinAgeofChild  and MaxAgeofChild is greater than or equal to 100, 
# then, replace with median of the respective column

# split the data into train and test data sets

# BUILD LINEAR REGRESSION MODEL 

# build model with all attributes into model 
#Error verification on train data
#Error verification on test data

#Exp2- Variable Transformations Y and/or X variables
#Y Variable Transformation - Apply log 
datatemp$TotalRevenueGenerated <- log(datatemp$TotalRevenueGenerated)
# Build the model and compute the error metrics 
#X Variable Transformation  and Build the model and validate

#Exp3- Variable Interactions

dataForModel = data

# split the data into train and test data sets
rows=seq(1,nrow(dataForModel),1)
set.seed(123)
trainRows=sample(rows,(70*nrow(dataForModel))/100)
train = dataForModel[trainRows,] 
test = dataForModel[-trainRows,] 

# BUILD LINEAR REGRESSION MODEL 

# build model with all attributes into model 
LinReg6<- lm(TotalRevenueGenerated ~ .^2, data=train)
#LinReg6<- lm(TotalRevenueGenerated ~ (x1+x2+x3)^2,data=train)
summary(LinReg6)
par(mfrow=c(2,2))
plot(LinReg6)
plot(LinReg6,which=4)

#Error verification on train data
library(DMwR)
regr.eval(train$TotalRevenueGenerated, LinReg6$fitted.values) 
#Error verification on test data
Pred<-predict(LinReg6,test)
regr.eval(test$TotalRevenueGenerated, Pred)

