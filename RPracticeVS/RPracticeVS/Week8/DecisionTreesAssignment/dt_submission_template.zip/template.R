train <- read.csv('Train.csv')
test <- read.csv('Test.csv')
#############MODIFY YOUR CODE BELOW######################





#############DO NOT MODIFY YOUR CODE FROM HERE ONWARDS ###########
write.csv(data.frame(predictions), 'predictions.csv', quote=F, row.names = F)
